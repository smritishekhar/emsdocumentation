package com.cg.service;

import com.cg.exception.EmployeeException;
import com.cg.models.Employee;

public interface IEmployeeService {

Employee compare(String id) throws EmployeeException;
}