package com.cg.service;

import com.cg.dao.EmployeeDAO;
import com.cg.dao.IEmployeeDAO;
import com.cg.exception.EmployeeException;
import com.cg.models.Employee;


public class EmployeeServiceImpl implements IEmployeeService { 
	IEmployeeDAO dao=new EmployeeDAO();

@Override
public Employee compare(String id) throws EmployeeException {
    return dao.compare(id);
}
}