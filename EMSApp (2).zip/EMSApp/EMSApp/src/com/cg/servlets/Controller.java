package com.cg.servlets;

import java.io.IOException;

import javax.servlet.RequestDispatcher; 
import javax.servlet.ServletException; 
import javax.servlet.annotation.WebServlet; 
import javax.servlet.http.HttpServlet; 
import javax.servlet.http.HttpServletRequest; 
import javax.servlet.http.HttpServletResponse;

import com.cg.exception.EmployeeException;
import com.cg.models.Employee;
import com.cg.service.EmployeeServiceImpl;
import com.cg.service.IEmployeeService;





  @WebServlet("*.mvc")
 public class Controller extends HttpServlet 
 {
	  private static final long serialVersionUID = 1L;
IEmployeeService service;
 Employee emp;

@Override public void init() throws ServletException 
{ 
	service=new EmployeeServiceImpl();
}

protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
{ 
	String action=request.getServletPath();

switch (action) {
case "/form.mvc":
    String id=request.getParameter("id");
    String pass=request.getParameter("password");
    System.out.println(id);
    System.out.println(pass);
    try {
        emp=service.compare(id);
        System.out.println(emp);
        
        } 
    catch (EmployeeException e) {
        e.printStackTrace();

        }
    if(id.equals(emp.getId()) && pass.equals(emp.getPassword()))
    {
        System.out.println("Welcome"+emp.getName());
        System.out.println("Welcome"+emp.getUsertype());
        request.setAttribute("emp",emp);
        RequestDispatcher rd = request.getRequestDispatcher("Admin.jsp");
        rd.forward(request, response);
    }else{
    	 System.out.println("sorry CAN NOT login");
         request.setAttribute("Employee",emp);
         RequestDispatcher rd = request.getRequestDispatcher("error.jsp");
         rd.forward(request, response);
    }
    break;

default:
    break;
}
}

protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException { 
	doGet(request, response); 
	}

}