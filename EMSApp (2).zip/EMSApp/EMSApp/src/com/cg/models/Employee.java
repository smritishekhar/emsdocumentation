package com.cg.models;

public class Employee {

private String id;
private String name;
private String password;
private String usertype;
public String getId() {
	return id;
}
public void setId(String id) {
	this.id = id;
}
public String getName() {
	return name;
}
public void setName(String name) {
	this.name = name;
}
public String getPassword() {
	return password;
}
public void setPassword(String password) {
	this.password = password;
}
public String getUsertype() {
	return usertype;
}
public void setUsertype(String usertype) {
	this.usertype = usertype;
}
public Employee() {
	super();
	// TODO Auto-generated constructor stub
}
public Employee(String id, String name, String password, String usertype) {
	super();
	this.id = id;
	this.name = name;
	this.password = password;
	this.usertype = usertype;
}
@Override
public String toString() {
	return "Employee [id=" + id + ", name=" + name + ", password=" + password
			+ ", usertype=" + usertype + "]";
}
@Override
public int hashCode() {
	final int prime = 31;
	int result = 1;
	result = prime * result + ((id == null) ? 0 : id.hashCode());
	result = prime * result + ((name == null) ? 0 : name.hashCode());
	result = prime * result + ((password == null) ? 0 : password.hashCode());
	result = prime * result + ((usertype == null) ? 0 : usertype.hashCode());
	return result;
}
@Override
public boolean equals(Object obj) {
	if (this == obj)
		return true;
	if (obj == null)
		return false;
	if (getClass() != obj.getClass())
		return false;
	Employee other = (Employee) obj;
	if (id == null) {
		if (other.id != null)
			return false;
	} else if (!id.equals(other.id))
		return false;
	if (name == null) {
		if (other.name != null)
			return false;
	} else if (!name.equals(other.name))
		return false;
	if (password == null) {
		if (other.password != null)
			return false;
	} else if (!password.equals(other.password))
		return false;
	if (usertype == null) {
		if (other.usertype != null)
			return false;
	} else if (!usertype.equals(other.usertype))
		return false;
	return true;
}

//Getters and Setters


}