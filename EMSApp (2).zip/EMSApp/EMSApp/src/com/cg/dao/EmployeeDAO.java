package com.cg.dao;

import java.sql.Connection;
import java.sql.PreparedStatement; 
import java.sql.ResultSet; 
import java.sql.SQLException;

import javax.naming.NamingException;

import com.cg.exception.EmployeeException;
import com.cg.models.Employee;
import com.cg.util.DBUtil;



public class EmployeeDAO implements IEmployeeDAO { 
	Connection conn; 
	PreparedStatement pstm; 
	ResultSet rs;
	Employee user;
private static final String GET_QUERY="select id,name,password,usertype from Employes1 where id=?";

@Override
public Employee compare(String id) throws EmployeeException {
	 user=new Employee();
    try {
        conn=DBUtil.getConnection();
        pstm=conn.prepareStatement(GET_QUERY);
        pstm.setString(1, id);
        ResultSet resOne=pstm.executeQuery();
        while(resOne.next())
        {
            
             user.setId(resOne.getString("id"));
             user.setName(resOne.getString("name"));
             user.setPassword(resOne.getString("password"));
             user.setUsertype(resOne.getString("usertype"));
             System.out.println("in dao" +user.getUsertype());
             
             
        }

    }   
    catch(SQLException | NamingException e )
    {
        e.printStackTrace();
    }
    finally
    {
        try{
            pstm.close();
            conn.close();
        }
        catch(SQLException e)
        {
            e.printStackTrace();
        }
    }
    System.out.println(user);
    return user;
}
}