package com.cg.dao;

import com.cg.exception.EmployeeException;
import com.cg.models.Employee;

public interface IEmployeeDAO {

Employee compare(String id) throws EmployeeException;
}